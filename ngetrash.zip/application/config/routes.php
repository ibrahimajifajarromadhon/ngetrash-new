<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'user';
$route['404_override'] = 'NotFound';
$route['translate_uri_dashes'] = FALSE;

$route['admin/login'] = 'Admin/login';
$route['admin/register'] = 'Admin/register';

$route['admin_petugas'] = 'AdminPetugas';
$route['admin_petugas/ubah_status/(:num)'] = 'AdminPetugas/ubah_status/$1';
$route['admin_petugas/page/(:num)'] = 'AdminPetugas/index/$1';
$route['admin_petugas/add'] = 'AdminPetugas/add';
$route['admin_petugas/save'] = 'AdminPetugas/save';
$route['admin_petugas/get_by_id/(:num)'] = 'AdminPetugas/get_by_id/$1';
$route['admin_petugas/edit'] = 'AdminPetugas/edit';
$route['admin_petugas/delete/(:num)'] = 'AdminPetugas/delete/$1';

$route['admin_user'] = 'AdminUser';
$route['admin_user/page/(:num)'] = 'AdminUser/index/$1';
$route['admin_user/add'] = 'AdminUser/add';
$route['admin_user/save'] = 'AdminUser/save';
$route['admin_user/get_by_id/(:num)'] = 'AdminUser/get_by_id/$1';
$route['admin_user/edit'] = 'AdminUser/edit';
$route['admin_user/delete/(:num)'] = 'AdminUser/delete/$1';

$route['admin_print/laporan_petugas/page/(:num)'] = 'Admin/laporan_petugas/$1';
$route['admin_print/laporan_user/page/(:num)'] = 'Admin/laporan_user/$1';
$route['admin_print/laporan_iuran/page/(:num)'] = 'Admin/laporan_iuran/$1';
$route['admin_print/laporan_status/page/(:num)'] = 'Admin/laporan_status/$1';

$route['admin_print/laporan_petugas'] = 'Admin/laporan_petugas';
$route['admin_print/laporan_user'] = 'Admin/laporan_user';
$route['admin_print/laporan_iuran'] = 'Admin/laporan_iuran';
$route['admin_print/laporan_status'] = 'Admin/laporan_status';

$route['admin_print/print_petugas'] = 'Admin/print_petugas';
$route['admin_print/print_user'] = 'Admin/print_user';
$route['admin_print/print_iuran'] = 'Admin/print_iuran';
$route['admin_print/print_status'] = 'Admin/print_status';

$route['petugas/login'] = 'Petugas/login';
$route['petugas/register'] = 'Petugas/register';

$route['petugas_iuran'] = 'PetugasIuran';
$route['petugas_iuran/add'] = 'PetugasIuran/add';
$route['petugas_iuran/save'] = 'PetugasIuran/save';
$route['petugas_iuran/edit'] = 'PetugasIuran/edit';
$route['petugas_iuran/page/(:num)'] = 'PetugasIuran/index/$1';
$route['petugas_iuran/get_by_id/(:num)'] = 'PetugasIuran/get_by_id/$1';
$route['petugas_iuran/delete/(:num)'] = 'PetugasIuran/delete/$1';

$route['petugas_status'] = 'PetugasStatus';
$route['petugas_status/scan'] = 'PetugasStatus/scan';
$route['petugas_status/get_by_id/(:num)'] = 'PetugasStatus/get_by_id/$1';

$route['petugas_status/process_scan'] = 'PetugasStatus/process_scan';
$route['petugas_status/edit'] = 'PetugasStatus/edit';
$route['petugas_status/page/(:num)'] = 'PetugasStatus/index/$1';
$route['petugas_status/delete/(:num)'] = 'PetugasStatus/delete/$1';

$route['user/login'] = 'User/login';
$route['user/register'] = 'User/register';

$route['user'] = 'User';
$route['user/status'] = 'UserStatus';
$route['user/status/page/(:num)'] = 'UserStatus/index/$1';
$route['user/riwayat'] = 'UserRiwayat';
$route['user/riwayat/page/(:num)'] = 'UserRiwayat/index/$1';

$route['admin_user_qrcode'] = 'AdminQRCode';
$route['admin_user_qrcode/page/(:num)'] = 'AdminQRCode/index/$1';
$route['admin_user_qrcode/generate_qr_code/(:num)'] = 'AdminQRCode/generate_qr_code/$1';
$route['admin_user_qrcode/download_qr_code/(:num)'] = 'AdminQRCode/download_qr_code/$1';
